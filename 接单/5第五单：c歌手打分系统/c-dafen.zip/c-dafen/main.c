#include "singer_management.h"
#include <windows.h>

int main() {
    // 设置控制台代码页为GBK
    SetConsoleOutputCP(936);
    SetConsoleCP(936);
    
    Singer singers[MAX_SINGERS];
    Judge judges[MAX_JUDGES];
    int numSingers, numJudges;
    char choice;

    printf("欢迎使用歌手比赛评分管理系统\n");

    // 检查是否存在已有的比赛结果
    FILE *fp = fopen("competition_results.txt", "r");
    if (fp != NULL) {
        printf("发现已有比赛结果，是否重新计算？，输入 Y 重新计算，输入 N 查看比赛结果(Y/N): ");
        scanf(" %c", &choice);
        fclose(fp);
        
        if (choice == 'N' || choice == 'n') {
            printf("正在显示已有结果...\n");
            if (loadResults(singers, judges, &numSingers, &numJudges)) {
                displayResults(singers, judges, numSingers, numJudges);
                printf("\n按任意键退出...");
                getchar();
                getchar();
            } else {
                printf("读取结果失败，将重新计算...\n");
                goto recalculate;
            }
            return 0;
        }
    }

recalculate:
    // 初始化系统
    initSystem(singers, judges, &numSingers, &numJudges);
    
    // 输入评分
    inputScores(singers, judges, numSingers, numJudges);
    
    // 计算平均分
    calculateAvgScores(singers, numSingers, numJudges);
    
    // 对选手排名
    rankSingers(singers, numSingers);
    
    // 评价评委
    evaluateJudges(singers, judges, numSingers, numJudges);
    
    // 保存结果
    saveResults(singers, judges, numSingers, numJudges);
    
    // 显示结果
    displayResults(singers, judges, numSingers, numJudges);

    printf("\n按任意键退出...");
    getchar();
    getchar();

    return 0;
} 