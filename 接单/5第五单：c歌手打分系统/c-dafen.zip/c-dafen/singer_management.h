#ifndef SINGER_MANAGEMENT_H
#define SINGER_MANAGEMENT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MAX_NAME_LEN 50
#define MAX_SINGERS 100
#define MAX_JUDGES 100

// 选手结构体
typedef struct {
    int id;
    char name[MAX_NAME_LEN];
    float scores[MAX_JUDGES];
    float avgScore;
    int rank;
} Singer;

// 评委结构体
typedef struct {
    int id;
    char name[MAX_NAME_LEN];
    float scoreDiffs;  // 评分差
    float useRate;     // 评分使用率
    char level[20];    // 评价等级
} Judge;

// 函数声明
void initSystem(Singer *singers, Judge *judges, int *numSingers, int *numJudges);
void inputScores(Singer *singers, Judge *judges, int numSingers, int numJudges);
void calculateAvgScores(Singer *singers, int numSingers, int numJudges);
void rankSingers(Singer *singers, int numSingers);
void evaluateJudges(Singer *singers, Judge *judges, int numSingers, int numJudges);
void saveResults(Singer *singers, Judge *judges, int numSingers, int numJudges);
void displayResults(Singer *singers, Judge *judges, int numSingers, int numJudges);
int loadResults(Singer *singers, Judge *judges, int *numSingers, int *numJudges);

#endif 