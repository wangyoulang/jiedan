#include "singer_management.h"

// 初始化系统
void initSystem(Singer *singers, Judge *judges, int *numSingers, int *numJudges) {
    printf("请输入选手人数: ");
    scanf("%d", numSingers);
    printf("请输入评委人数(需大于5): ");
    scanf("%d", numJudges);
    
    if (*numJudges <= 5) {
        printf("评委人数必须大于5！\n");
        exit(1);
    }

    // 初始化选手信息
    for (int i = 0; i < *numSingers; i++) {
        singers[i].id = i + 1;
        printf("请输入第%d号选手姓名: ", i + 1);
        scanf("%s", singers[i].name);
    }

    // 初始化评委信息
    for (int i = 0; i < *numJudges; i++) {
        judges[i].id = i + 1;
        printf("请输入第%d号评委姓名: ", i + 1);
        scanf("%s", judges[i].name);
        judges[i].scoreDiffs = 0;
        judges[i].useRate = 0;
    }
}

// 输入评分
void inputScores(Singer *singers, Judge *judges, int numSingers, int numJudges) {
    for (int i = 0; i < numSingers; i++) {
        printf("\n为选手 %s 评分:\n", singers[i].name);
        for (int j = 0; j < numJudges; j++) {
            float score;
            do {
                printf("评委 %s 的评分(1-10): ", judges[j].name);
                scanf("%f", &score);
            } while (score < 1 || score > 10);
            singers[i].scores[j] = score;
        }
    }
}

// 计算平均分
void calculateAvgScores(Singer *singers, int numSingers, int numJudges) {
    for (int i = 0; i < numSingers; i++) {
        float sum = 0, max = 0, min = 10;
        
        // 找出最高分和最低分
        for (int j = 0; j < numJudges; j++) {
            float score = singers[i].scores[j];
            if (score > max) max = score;
            if (score < min) min = score;
            sum += score;
        }
        
        // 去掉最高分和最低分后的平均分
        singers[i].avgScore = (sum - max - min) / (numJudges - 2);
    }
}

// 对选手排名
void rankSingers(Singer *singers, int numSingers) {
    // 使用冒泡排序
    for (int i = 0; i < numSingers - 1; i++) {
        for (int j = 0; j < numSingers - i - 1; j++) {
            if (singers[j].avgScore < singers[j + 1].avgScore) {
                Singer temp = singers[j];
                singers[j] = singers[j + 1];
                singers[j + 1] = temp;
            }
        }
    }
    
    // 设置排名
    for (int i = 0; i < numSingers; i++) {
        singers[i].rank = i + 1;
    }
}

// 评价评委
void evaluateJudges(Singer *singers, Judge *judges, int numSingers, int numJudges) {
    for (int j = 0; j < numJudges; j++) {
        int usedScores = 0;
        float totalDiff = 0;
        
        for (int i = 0; i < numSingers; i++) {
            float diff = fabs(singers[i].scores[j] - singers[i].avgScore);
            totalDiff += diff;
            
            // 检查是否为最高分或最低分
            float score = singers[i].scores[j];
            int isExtreme = 0;
            for (int k = 0; k < numJudges; k++) {
                if (k != j && (singers[i].scores[k] > score || singers[i].scores[k] < score)) {
                    isExtreme = 1;
                    break;
                }
            }
            if (!isExtreme) usedScores++;
        }
        
        judges[j].scoreDiffs = totalDiff / numSingers;
        judges[j].useRate = (float)usedScores / numSingers * 100;
        
        // 评定等级
        if (judges[j].useRate < 30) {
            strcpy(judges[j].level, "不可用");
        } else if (judges[j].useRate > 80) {
            strcpy(judges[j].level, "超好");
        } else {
            strcpy(judges[j].level, "一般");
        }
    }
}

// 保存结果到文件
void saveResults(Singer *singers, Judge *judges, int numSingers, int numJudges) {
    FILE *fp = fopen("competition_results.txt", "w");
    if (fp == NULL) {
        printf("无法创建文件！\n");
        return;
    }

    fprintf(fp, "选手比赛结果：\n");
    fprintf(fp, "排名\t编号\t姓名\t平均分\n");
    for (int i = 0; i < numSingers; i++) {
        fprintf(fp, "%d\t%d\t%s\t%.2f\n", 
                singers[i].rank, singers[i].id, 
                singers[i].name, singers[i].avgScore);
    }

    fprintf(fp, "\n评委评分水平：\n");
    fprintf(fp, "编号\t姓名\t评分差\t使用率\t评价\n");
    for (int i = 0; i < numJudges; i++) {
        fprintf(fp, "%d\t%s\t%.2f\t%.2f%%\t%s\n", 
                judges[i].id, judges[i].name, 
                judges[i].scoreDiffs, judges[i].useRate, 
                judges[i].level);
    }

    fclose(fp);
}

// 显示结果
void displayResults(Singer *singers, Judge *judges, int numSingers, int numJudges) {
    printf("\n选手比赛结果：\n");
    printf("排名\t编号\t姓名\t平均分\n");
    for (int i = 0; i < numSingers; i++) {
        printf("%d\t%d\t%s\t%.2f\n", 
               singers[i].rank, singers[i].id, 
               singers[i].name, singers[i].avgScore);
    }

    printf("\n评委评分水平：\n");
    printf("编号\t姓名\t评分差\t使用率\t评价\n");
    for (int i = 0; i < numJudges; i++) {
        printf("%d\t%s\t%.2f\t%.2f%%\t%s\n", 
               judges[i].id, judges[i].name, 
               judges[i].scoreDiffs, judges[i].useRate, 
               judges[i].level);
    }
}

// 从文件加载比赛结果
int loadResults(Singer *singers, Judge *judges, int *numSingers, int *numJudges) {
    FILE *fp = fopen("competition_results.txt", "r");
    if (fp == NULL) {
        printf("无法打开结果文件！\n");
        return 0;
    }

    char line[256];
    *numSingers = 0;
    *numJudges = 0;

    // 跳过标题行
    fgets(line, sizeof(line), fp);
    fgets(line, sizeof(line), fp);

    // 读取选手信息
    while (fgets(line, sizeof(line), fp)) {
        if (line[0] == '\n') break;
        
        Singer *s = &singers[*numSingers];
        sscanf(line, "%d\t%d\t%s\t%f",
               &s->rank, &s->id, s->name, &s->avgScore);
        (*numSingers)++;
    }

    // 跳过评委信息标题行
    fgets(line, sizeof(line), fp);
    fgets(line, sizeof(line), fp);

    // 读取评委信息
    while (fgets(line, sizeof(line), fp)) {
        if (line[0] == '\n') break;
        
        Judge *j = &judges[*numJudges];
        sscanf(line, "%d\t%s\t%f\t%f%%\t%s",
               &j->id, j->name, &j->scoreDiffs, &j->useRate, j->level);
        (*numJudges)++;
    }

    fclose(fp);
    return 1;
} 