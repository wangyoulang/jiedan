export default {
    baseUrl: 'http://localhost:8080/djangofskyf/',
    indexNav: [
        {
            name: '首页',
            url: '/index/home'
        },
        {
            name: '健康知识',
            url: '/index/jiankangzhishi'
        },
        {
            name: '疫情资讯',
            url: '/index/yiqingzixun'
        },
        {
            name: '康友圈',
            url: '/index/forum'
        }, 
        {
            name: '实时资讯',
            url: '/index/news'
        },
    ]
}
