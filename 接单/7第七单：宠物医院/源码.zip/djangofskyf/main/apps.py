from django.apps import AppConfig


class MainConfig(AppConfig):
    name = 'main'
    verbose_name = verbose_name_plural = r'刷表模块'
